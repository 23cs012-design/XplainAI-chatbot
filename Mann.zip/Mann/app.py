from flask import Flask, request, jsonify, render_template
from groq import Groq
import os

app = Flask(__name__)

GROQ_API_KEY = os.getenv("")
client = Groq(api_key="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")


try:
    with open("knowledge.txt", "r", encoding="utf-8") as file:
        knowledge = file.read()
except:
    knowledge = "No knowledge base found."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    try:
        data = request.get_json()
        user_message = data.get("message", "").strip()

        if not user_message:
            return jsonify({"response": "Please type a question."})

        # 👋 Greeting handling
        if user_message.lower() in ["hi", "hello", "hey"]:
            return jsonify({
                "response": "Hello! I am XplainAI 🤖. Ask me anything about Artificial Intelligence."
            })

        completion = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {
                    "role": "system",
                    "content": (
                       "You are an AI tutor.\n\n"
        "STRICT RULES:\n"
        "- Answer ONLY what is asked, and give simple one line explanations. about what is asked.\n"
        "- Do NOT add definition unless explicitly asked.\n"
        "- If user asks 'applications',then first write the applications of {topic} are:, give ONLY applications.\n"
        "- If user asks 'types',then first write the types of {topic} are: ,then give ONLY types and its definitions with examples of its types.\n"
        "- If user asks 'what is AI or what is machine learning' like question on what, give simple definition and examples, keep minimal and simple so one can understand easily.\n"
        "- No introduction,\n"
        "- No conclusion, no long explanations, keep minimal and simple so one can understand easily.\n"
        "- Use bullet points only.\n"
        "- Maximum 5 points.\n"
        "- Keep each point in one short line.\n\n"
        "Format:\n"
        "• Point 1\n"
        "• Point 2\n"
        "• Point 3\n\n"
                    )
                },
                {
                     "role": "user",
    "content": f"""
    Knowledge:
    {knowledge}

    Question:
    {user_message}

    Follow all rules strictly.
    """
                }
            ],
        )

        bot_reply = completion.choices[0].message.content.strip()

        print("User:", user_message)
        print("Bot:", bot_reply)

        return jsonify({"response": bot_reply})

    except Exception as e:
        print("ERROR:", e)
        return jsonify({"response": "⚠️ Server error. Check backend."})


if __name__ == "__main__":
    app.run(debug=True)